from django.contrib import admin

# Register your models here.

from .models import Artista, Usuario, Localidad, Escenario, Concierto, Entrada, Reserva, Pago

admin.site.register(Artista)
admin.site.register(Usuario)
admin.site.register(Localidad)
admin.site.register(Escenario)
admin.site.register(Concierto)
admin.site.register(Entrada)
admin.site.register(Reserva)
admin.site.register(Pago)
