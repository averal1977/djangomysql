from django.db import models

# Create your models here.
from django.db import models
from django.utils import timezone
from datetime import date

# Create your models here.
class Artista (models.Model):
    nombre_artistico = models.CharField(max_length=30)
    nombre = models.CharField(max_length=30)
    apellido = models.CharField(max_length=30)
    nacionalidad = models.CharField(max_length=50, null=True, blank=True)

class Usuario (models.Model):
    login = models.CharField(max_length=15)
    clave = models.CharField(max_length=15)
    nombre = models.CharField(max_length=30)
    apellido = models.CharField(max_length=30)
    cedula = models.CharField(max_length=10)
    correo = models.CharField(max_length=50, null=True, blank=True)
    telefono = models.CharField(max_length=30, null=True, blank=True)

class Localidad (models.Model):
    descripcion = models.CharField(max_length=30)

class Escenario (models.Model):
    descripcion = models.CharField(max_length=30)
    capacidad = models.IntegerField(default=0)

class Concierto (models.Model):
    nombre = models.CharField(max_length=30)    
    fecha = models.DateTimeField(default=timezone.now)
    hora_inicio = models.DateTimeField(default=timezone.now)
    hora_fin = models.DateTimeField(default=timezone.now)
    descripcion = models.CharField(max_length=30)
    artista = models.ForeignKey('Artista', on_delete=models.PROTECT, related_name='artista')
    escenario = models.ForeignKey('Escenario', on_delete=models.PROTECT, related_name='escenario')
    entradas_disponibles = models.IntegerField(default=0)
    

class Entrada (models.Model):
    localidad = models.ForeignKey('Localidad', on_delete=models.PROTECT, related_name='localidad')
    concierto = models.ForeignKey('Concierto', on_delete=models.PROTECT, related_name='concierto')
    asiento = models.IntegerField(default=0)
    precio = models.FloatField(default=0)

class Reserva (models.Model):
    fecha_creacion = models.DateTimeField(default=timezone.now)
    usuario = models.ForeignKey('Usuario', on_delete=models.PROTECT, related_name='usuario')
    entrada = models.ForeignKey('Entrada', on_delete=models.PROTECT, related_name='entrada')
    esta_anulada = models.BooleanField(default=False)

class Pago (models.Model):
    fecha_creacion = models.DateTimeField(default=timezone.now)
    reserva = models.ForeignKey('Reserva', on_delete=models.PROTECT, related_name='reserva')
    forma_pago = models.CharField(max_length=30)
    total = models.FloatField(default=0)
